import java.io.*;
import java.util.*;

public class seeing_eye_to_eye {
	static class C {
		int h;
		boolean foo;
		C(int h, boolean foo) {
			this.h = h; this.foo = foo;
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		C[] cc = new C[n + m];
		st = new StringTokenizer(br.readLine());
		for (int i = 0; i < n; i++) {
			int h = Integer.parseInt(st.nextToken());
			cc[i] = new C(h, true);
		}
		st = new StringTokenizer(br.readLine());
		for (int j = 0; j < m; j++) {
			int h = Integer.parseInt(st.nextToken());
			cc[n + j] = new C(h, false);
		}
		Arrays.sort(cc, (a, b) -> a.h - b.h);
		int d = Integer.MAX_VALUE;
		for (int i = 1; i < n + m; i++)
			if (cc[i].foo != cc[i - 1].foo)
				d = Math.min(d, cc[i].h - cc[i - 1].h);
		System.out.println(d);
	}
}
