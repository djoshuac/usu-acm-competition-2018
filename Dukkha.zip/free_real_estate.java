import java.io.*;
import java.util.*;

public class free_real_estate {
	static class H {
		int b, t, p;
		H(int b, int t, int p) {
			this.b = b; this.t = t; this.p = p;
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		H[] hh = new H[n];
		for (int i = 0; i < n; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			int b = Integer.parseInt(st.nextToken());
			int t = Integer.parseInt(st.nextToken());
			int p = Integer.parseInt(st.nextToken());
			hh[i] = new H(b, t, p);
		}
		Arrays.sort(hh, (x, y) -> x.b != y.b ? y.b - x.b : x.p != y.p ? y.p - x.p : y.t - x.t);
		int[] tt = new int[11];
		Arrays.fill(tt, -1);
		int cnt = 0;
		for (int i = 0; i < n; i++) {
			H h = hh[i];
			if (h.t > tt[h.p]) {
				cnt++;
				for (int p = 0; p <= h.p; p++)
					tt[p] = Math.max(tt[p], h.t);
			}
		}
		System.out.println(cnt);
	}
}
