import java.io.*;
import java.util.*;

public class minion_data_entry {
	static boolean check_phone(String s) {
		char[] cc = s.toCharArray();
		if (cc.length != 12)
			return false;
		for (int i = 0; i < 12; i++) {
			char c = cc[i];
			if (i == 3 || i == 7) {
				if (c != '-')
					return false;
			} else {
				if (c < '0' || c > '9')
					return false;
			}
		}
		return true;
	}
	static boolean check_email(String s) {
		char[] cc = s.toCharArray();
		boolean at = false, dot = false;
		int cnt1 = 0, cnt2 = 0, cnt3 = 0;
		for (int i = 0; i < cc.length; i++) {
			int c = cc[i];
			if (c == '@') {
				if (at || cnt1 == 0)
					return false;
				at = true;
			} else if (c == '.') {
				if (!at || dot || cnt2 == 0)
					return false;
				dot = true;
			} else if (!at) {
				if (c == '_' || c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c >= '0' && c <= '9')
					cnt1++;
				else
					return false;
			} else if (!dot) {
				if (c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z')
					cnt2++;
				else
					return false;
			} else {
				if (c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z')
					cnt3++;
				else
					return false;
			}
		}
		return at && dot && cnt3 >= 2 && cnt3 <= 3;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		StringBuilder sb = new StringBuilder();
		while (n-- > 0) {
			String s = br.readLine();
			sb.append(s);
		}
		char[] cc = sb.toString().toCharArray();
		n = cc.length;
		ArrayList<String> stack = new ArrayList<>();
		int k = 0;
		for (int i = 0; i < n; i++) {
			if (cc[i] == '<') {
				int j = i + 1;
				while (j < n && cc[j] != '>')
					j++;
				if (j == n) {
					System.out.println("False");
					return;
				}
				if (cc[i + 1] == '/') {
					String _s = new String(cc, i + 2, j - i - 2);
					if (k == 0) {
						System.out.println("False");
						return;
					}
					String s = stack.remove(--k);
					if (!s.equals(_s)) {
						System.out.println("False");
						return;
					}
				} else {
					String s = new String(cc, i + 1, j - i - 1);
					stack.add(s);
					k++;
					if (s.equals("phone") || s.equals("email")) {
						int p = j + 1, q = j + 1;
						while (q < n && cc[q] != '<')
							q++;
						if (p > q) {
							System.out.println("False");
							return;
						}
						String t = new String(cc, p, q - p).trim();
						if (s.equals("phone")) {
							if (!check_phone(t)) {
								System.out.println("False");
								return;
							}
						} else {
							if (!check_email(t)) {
								System.out.println("False");
								return;
							}
						}
					}
				}
				i = j;
			}
		}
		System.out.println(stack.isEmpty() ? "True" : "False");
	}
}
