import java.io.*;

public class dondald_drump {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		char[] ans = new char[4];
		for (int i = 0; i < 4; i++) {
			int h = 0, m = 0;
			for (int j = 0; j < 4; j++) {
				char[] cc = br.readLine().toCharArray();
				h += (cc[0] - '0') * 10 + (cc[1] - '0');
				m += (cc[2] - '0') * 10 + (cc[3] - '0');
			}
			h %= 24;
			m %= 60;
			int x = (h + m) % 42;
			while (x >= 10)
				x = x / 10 + x % 10;
			ans[i] = (char) ('0' + x);
		}
		System.out.println(ans);
	}
}
