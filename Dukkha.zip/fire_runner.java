import java.io.*;
import java.util.*;

public class fire_runner {
	static int n, x0, y0;
	static int[][] aa, ss;
	static void push1(int x, int y, int s) {
		if (x >= 0 && x < n && y >= 0 && y < n)
			ss[x][y] = Math.max(ss[x][y], aa[x][y] + s);
	}
	static void push(int x, int y) {
		if (x >= 0 && x < n && y >= 0 && y < n) {
			int s = ss[x][y];
			if (x <= x0)
				push1(x - 1, y, s);
			if (x >= x0)
				push1(x + 1, y, s);
			if (y <= y0)
				push1(x, y - 1, s);
			if (y >= y0)
				push1(x, y + 1, s);
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		aa = new int[n][n];
		ss = new int[n][n];
		for (int i = 0; i < n; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			for (int j = 0; j < n; j++)
				aa[i][j] = Integer.parseInt(st.nextToken());
		}
		int k = (n - 1) / 2;
		x0 = y0 = k;
		ss[x0][y0] = aa[x0][y0];
		for (int d = 0; d < k + k; d++)
			for (int dx = 0; dx <= d; dx++) {
				int dy = d - dx;
				for (int sx = -1; sx <= 1; sx += 2)
					for (int sy = -1; sy <= 1; sy += 2) {
						int x = x0 + dx * sx;
						int y = y0 + dy * sy;
						push(x, y);
					}
			}
		int max = Math.max(Math.max(ss[0][0], ss[n - 1][n - 1]), Math.max(ss[0][n - 1], ss[n - 1][0]));
		System.out.println(max);
	}
}
