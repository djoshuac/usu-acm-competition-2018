import java.io.*;
import java.util.*;

public class unique_stepping_stones {
	static int[][] aa;
	static int n, m;
	static int[] cc;
	static boolean solve(int j) {
		if (j == m)
			return true;
		for (int i = 0; i < n; i++) {
			int a = aa[i][j];
			boolean distinct = true;
			for (int h = 0; h < j; h++)
				if (aa[cc[h]][h] == a) {
					distinct = false;
					break;
				}
			if (distinct) {
				cc[j] = i;
				if (solve(j + 1))
					return true;
			}
		}
		return false;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		aa = new int[n][m];
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 0; j < m; j++)
				aa[i][j] = Integer.parseInt(st.nextToken());
		}
		cc = new int[m];
		System.out.println(solve(0) ? "Yes" : "No");
	}
}
