import java.io.*;

public class strange_doubling {
	static boolean duplicate(char[] cc, int n) {
		int m = n / 2;
		for (int i = 0, j = m; i < m; i++, j++)
			if (cc[i] != cc[j])
				return false;
		return true;
	}
	static int solve(char[] cc) {
		int n = cc.length, k = 0;
		while (n > 1) {
			if ((n & n - 1) == 0 && duplicate(cc, n))
				n /= 2;
			else
				n--;
			k++;
		}
		return k + 1;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		char[] cc = br.readLine().toCharArray();
		System.out.println(solve(cc));
	}
}
