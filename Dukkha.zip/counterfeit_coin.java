import java.io.*;

public class counterfeit_coin {
	static int solve(int n) {
		return n == 1 ? 0 : solve(n / 3 + (n % 3 == 0 ? 0 : 1)) + 1;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter pw = new PrintWriter(System.out);
		int t = Integer.parseInt(br.readLine());
		while (t-- > 0) {
			int n = Integer.parseInt(br.readLine());
			pw.println(solve(n));
		}
		pw.close();
	}
}
