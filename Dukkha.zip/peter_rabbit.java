import java.io.*;
import java.util.*;

public class peter_rabbit {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int[] dd = new int[n];
		st = new StringTokenizer(br.readLine());
		for (int i = 1; i < n; i++)
			dd[i] = Integer.parseInt(st.nextToken());
		for (int i = 1; i < n; i++)
			dd[i] += dd[i - 1];
		int min = dd[n - 1];
		for (int h = 0; h < m; h++) {
			st = new StringTokenizer(br.readLine());
			int i = Integer.parseInt(st.nextToken()) - 1;
			int j = Integer.parseInt(st.nextToken()) - 1;
			int d = Integer.parseInt(st.nextToken());
			min = Math.min(min, dd[n - 1] - (dd[j] - dd[i]) + d);
		}
		System.out.println(min);
	}
}
