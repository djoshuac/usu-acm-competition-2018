#include <stdio.h>

#define N	9
#define A	10000

int main() {
	static int bb[A + 1];
	static char dp[A + 1][1 << N];
	int n, m, i, j, a, b;

	scanf("%d%d", &n, &m);
	for (i = 0; i < n; i++)
		for (j = 0; j < m; j++) {
			scanf("%d", &a);
			bb[a] |= 1 << j;
		}
	dp[0][0] = 1;
	for (j = 0; j < m; j++)
		if ((bb[0] & 1 << j) > 0)
			dp[0][1 << j] = 1;
	for (a = 0; a < A; a++)
		if (bb[a + 1] == 0)
			for (b = 0; b < 1 << m; b++)
				dp[a + 1][b] = dp[a][b];
		else
			for (b = 0; b < 1 << m; b++)
				if (dp[a][b])
					for (j = 0; j < m; j++)
						if ((bb[a + 1] & 1 << j) > 0)
							dp[a + 1][b | 1 << j] = 1;
	printf(dp[A][(1 << m) - 1] ? "Yes\n" : "No\n");
	return 0;
}
