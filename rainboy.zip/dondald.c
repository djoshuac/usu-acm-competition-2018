#include <stdio.h>

int main() {
	static char cc[16];
	int sum1, sum2, k;

	sum1 = 0, sum2 = 0;
	k = 0;
	while (scanf("%s", cc) != EOF) {
		sum1 = (sum1 + (cc[0] - '0') * 10 + (cc[1] - '0')) % 24;
		sum2 = (sum2 + (cc[2] - '0') * 10 + (cc[3] - '0')) % 60;
		if (++k % 4 == 0) {
			printf("%d", ((sum1 + sum2) % 42 - 1) % 9 + 1);
			sum1 = sum2 = 0;
		}
	}
	printf("\n");
	return 0;
}
