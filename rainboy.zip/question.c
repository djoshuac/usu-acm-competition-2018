#include <stdio.h>
#include <string.h>

int main() {
	static char cc[1024];
	int n;

	scanf("%d\n", &n);
	while (n-- > 0) {
		fgets(cc, 1024, stdin);
		cc[strlen(cc) - 1] = '\0';
		printf("%s 42\n", cc);
	}
	return 0;
}
