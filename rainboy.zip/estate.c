/* http://codeforces.com/contest/12/problem/D */
#include <stdio.h>
#include <stdlib.h>

#define N	1300000
#define P	10

struct H {
	int b, t, p;
} *hh[N];

struct H *new_H(int b, int t, int p) {
	struct H *h = malloc(sizeof *h);

	h->b = b, h->t = t, h->p = p;
	return h;
}

int compare(const void *a, const void *b) {
	struct H *pa = *(struct H **) a;
	struct H *pb = *(struct H **) b;

	return pa->b != pb->b ? pb->b - pa->b : pa->t != pb->t ? pb->t - pa->t : pb->p - pa->p;
}

int main() {
	static int aa[P + 1];
	int n, i, b, t, p, max, cnt;

	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d%d%d", &b, &t, &p);
		hh[i] = new_H(b, t, p);
	}
	qsort(hh, n, sizeof *hh, compare);
	for (i = 0, cnt = 0; i < n; i++) {
		max = 0;
		for (p = hh[i]->p; p <= P; p++)
			if (max < aa[p])
				max = aa[p];
		if (max < hh[i]->t)
			cnt++;
		if (aa[hh[i]->p] < hh[i]->t)
			aa[hh[i]->p] = hh[i]->t;
	}
	printf("%d\n", cnt);
	return 0;
}
