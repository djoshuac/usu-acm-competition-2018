#include <ctype.h>
#include <stdio.h>
#include <string.h>

#define N	1000000

int phone(char *cc, int i, int j) {
	if (j - i != 12)
		return 0;
	if (!isdigit(cc[i]) || !isdigit(cc[i + 1]) || !isdigit(cc[i + 2]))
		return 0;
	if (cc[i + 3] != '-')
		return 0;
	if (!isdigit(cc[i + 4]) || !isdigit(cc[i + 5]) || !isdigit(cc[i + 6]))
		return 0;
	if (cc[i + 7] != '-')
		return 0;
	if (!isdigit(cc[i + 8]) || !isdigit(cc[i + 9]) || !isdigit(cc[i + 10]) || !isdigit(cc[i + 11]))
		return 0;
	return 1;
}

int email(char *cc, int i, int j) {
	int h;

	for (h = i; h < j && cc[h] != '@'; h++)
		if (cc[h] != '_' && !isalpha(cc[h]) && !isdigit(cc[h]))
			return 0;
	if (h == j)
		return 0;
	for (h++; h < j && cc[h] != '.'; h++)
		if (!isalpha(cc[h]))
			return 0;
	if (h == j || (j - h - 1 != 2 && j - h - 1 != 3))
		return 0;
	for (h++; h < j; h++)
		if (!isalpha(cc[h]))
			return 0;
	return 1;
}

int main() {
	static char cc[N], s[N], *ss[N];
	static int ii[N];
	int n, m, i, j, cnt;

	scanf("%d", &n);
	while (scanf("%s", s) != EOF)
		strcat(cc, s);
	m = strlen(cc);
	cnt = 0;
	for (i = 0; i < m; i++)
		if (cc[i] == '<') {
			j = i + 1;
			while (cc[j] != '>') {
				s[j - i - 1] = cc[j];
				j++;
			}
			s[j - i - 1] = '\0';
			if (s[0] == '/') {
				if (cnt == 0 || strcmp(ss[cnt - 1], s + 1) != 0) {
					printf("False\n");
					return 0;
				}
				if (strcmp(ss[cnt - 1], "phone") == 0 && !phone(cc, ii[cnt - 1] + 7, i)) {
					printf("False\n");
					return 0;
				}
				if (strcmp(ss[cnt - 1], "email") == 0 && !email(cc, ii[cnt - 1] + 7, i)) {
					printf("False\n");
					return 0;
				}
				cnt--;
			} else {
				ss[cnt] = strdup(s);
				ii[cnt] = i;
				cnt++;
			}
			i = j;
		}
	printf(cnt == 0 ? "True\n" : "False\n");
	return 0;
}
