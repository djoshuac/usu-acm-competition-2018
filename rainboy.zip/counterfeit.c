#include <stdio.h>

int main() {
	int t;

	scanf("%d", &t);
	while (t-- > 0) {
		int n, k;

		scanf("%d", &n);
		k = 0;
		while (n > 1)
			n = (n + 2) / 3, k++;
		printf("%d\n", k);
	}
	return 0;
}
