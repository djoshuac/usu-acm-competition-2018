#include <stdio.h>
#include <string.h>

#define N	1000000

int main() {
	static char s[N + 1], p2[N];
	int a, k, i;
	
	scanf("%s", s);
	for (a = 1; a < 20; a++)
		p2[(1 << a) - 1] = 1;
	k = 0;
	for (i = strlen(s) - 1; i >= 0; k++)
		if (p2[i] && strncmp(s, s + (i + 1) / 2, (i + 1) / 2) == 0)
			i /= 2;
		else
			i--;
	printf("%d\n", k);
	return 0;
}
