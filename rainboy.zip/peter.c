#include <stdio.h>

#define N	1000000

int main() {
	static int aa[N];
	int n, m, i, j, d, min;

	scanf("%d%d", &n, &m);
	for (i = 1; i < n; i++)
		scanf("%d", &aa[i]);
	for (i = 1; i < n; i++)
		aa[i] += aa[i - 1];
	min = aa[n - 1];
	while (m-- > 0) {
		scanf("%d%d%d", &i, &j, &d);
		i--, j--;
		if (min > aa[i] + d + aa[n - 1] - aa[j])
			min = aa[i] + d + aa[n - 1] - aa[j];
	}
	printf("%d\n", min);
	return 0;
}
