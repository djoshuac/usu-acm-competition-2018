#include <stdio.h>

#define N	350

int max;

void solve(int bb[][N], int n) {
	static int dp[N][N];
	int i, j;

	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++) {
			dp[i][j] = 0;
			if (i > 0 && dp[i][j] < dp[i - 1][j])
				dp[i][j] = dp[i - 1][j];
			if (j > 0 && dp[i][j] < dp[i][j - 1])
				dp[i][j] = dp[i][j - 1];
			dp[i][j] += bb[i][j];
		}
	if (max < dp[n - 1][n - 1])
		max = dp[n - 1][n - 1];
}

int main() {
	static int aa[N][N], bb[N][N];
	int n, i, j;

	scanf("%d", &n);
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &aa[i][j]);
	max = 0;
	for (i = n / 2; i < n; i++)
		for (j = n / 2; j < n; j++)
			bb[i - n / 2][j - n / 2] = aa[i][j];
	solve(bb, (n + 1) / 2);
	for (i = n / 2; i < n; i++)
		for (j = n / 2; j >= 0; j--)
			bb[i - n / 2][n / 2 - j] = aa[i][j];
	solve(bb, (n + 1) / 2);
	for (i = n / 2; i >= 0; i--)
		for (j = n / 2; j < n; j++)
			bb[n / 2 - i][j - n / 2] = aa[i][j];
	solve(bb, (n + 1) / 2);
	for (i = n / 2; i >= 0; i--)
		for (j = n / 2; j >= 0; j--)
			bb[n / 2 - i][n / 2 - j] = aa[i][j];
	solve(bb, (n + 1) / 2);
	printf("%d\n", max);
	return 0;
}
