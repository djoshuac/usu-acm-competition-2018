#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
	int *aa;
	int n, m, i, b, min;

	scanf("%d%d", &n, &m);
	aa = malloc(n * sizeof *aa);
	for (i = 0; i < n; i++)
		scanf("%d", &aa[i]);
	min = INT_MAX;
	i = -1;
	while (m-- > 0) {
		scanf("%d", &b);
		while (i + 1 < n && aa[i + 1] < b)
			i++;
		if (i + 1 < n && min > aa[i + 1] - b)
			min = aa[i + 1] - b;
		if (i >= 0 && min > b - aa[i])
			min = b - aa[i];
	}
	printf("%d\n", min);
	return 0;
}
